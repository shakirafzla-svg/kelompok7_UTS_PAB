package com.example.kel7uts

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
